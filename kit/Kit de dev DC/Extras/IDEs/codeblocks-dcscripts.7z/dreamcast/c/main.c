#include <kos.h>

int main(int argc, char **argv)
{
    printf("\nHello world!\n\n");
    return 0;
}
