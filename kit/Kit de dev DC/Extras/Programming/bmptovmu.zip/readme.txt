
	+-----------------------------------+
	| BmpToVmu by Speud (speud@free.fr) |
	|   http://blueswirl.shorturl.com   |
	+-----------------------------------+

 Description:
	Converts BMP image to color icon or eyecatch to
	include in Dreamcast VMU file.

 Supported BMP formats:
	32x32 - 1 or 4 bpp for icon
	72x56 - 1, 4, 8, 16, 24 or 32 bpp for eyecatch

 Syntax:
	bmptovmu <srcPath> <dstPath>
	<srcPath>: path of source BMP image
	<dstPath>: path of destination file

