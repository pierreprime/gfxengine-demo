#ifndef _CPICTURE_H_
#define _CPICTURE_H_

//-----------------------------------------------------------------------------
// define

#ifndef	_WINDOWS_
#include "windows.h"
#endif

#ifndef	_PCX_H_
#include "pcx.h"
#endif

#ifndef MAXCOLORS
#define	MAXCOLORS	256
#endif

#define RGB565(r, g, b) ((r >> 3) << 11) | ((g >> 2) << 5) | ((b >> 3) << 0);

//------------------------------------------------------------------------------
// class

class cPicture
{
	public:
	char FileName[MAX_PATH];
	int Width;
	int Height;
	int Bpp;
	int Pitch;
    unsigned char	*Pixels;
	unsigned char	*Palette;

	//-- Methods --
	cPicture();
	cPicture(int w,int h,int bpp);
	~cPicture();

	int Allocate(int w,int h,int bpp);
	int LoadFromPcx(char* filename);
    int SaveToPcx(char* filename);

	void SetPalette(unsigned char *pal);
};

#endif