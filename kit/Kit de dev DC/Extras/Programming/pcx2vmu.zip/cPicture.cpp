//-------------------------------------------------------------------
//
// CPicture Class
//
//
//-------------------------------------------------------------------
// Includes 

#include "cPicture.h"

#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>

//-------------------------------------------------------------------
// Constructeur qui alloue

cPicture::cPicture()
{
}

//-------------------------------------------------------------------
// Constructeur qui alloue

cPicture::cPicture(int w,int h,int bpp)
{
	Allocate(w,h,bpp);
}

//-------------------------------------------------------------------
/*cPicture::cPicture(const char* filename,const tPictureInfo *info)
{
	if(filename!=NULL)
		strcpy(this->FileName,filename);

	if(info!=NULL)
	{
		Width  = info->Width;
		Height = info->Height;
		Pitch  = info->Pitch;
		Bpp    = info->Bpp;
	}

	Data = (unsigned short*) malloc(Width * Height * BUFFER_BPP);
	Palette=(tRgb*) malloc(MAX_COLORS * sizeof(tRgb));
}*/

//-------------------------------------------------------------------
// Destructeur

cPicture::~cPicture()
{
	if(Pixels)
		free(Pixels);

	if(Palette)
		free(Palette);
}

//-------------------------------------------------------------------
// Alloue l'espace pour une image

int cPicture::Allocate(int w,int h,int bpp)
{
	Width=w;
	Height=h;
	Bpp=bpp;

	if(Width<=0 || Height<=0 || Bpp<=0)
		return 0;

	// si mode palettis�
	if(bpp==8)
	{	Palette= (unsigned char*) malloc(MAXCOLORS*3);
		if(!Palette)
			return 0;
	}

	// alloue
	Pixels = (unsigned char*) malloc( (bpp>>3) * Width * Height);
	if(!Pixels)
		return 0;

	memset(Pixels,0,(bpp>>3) * Width * Height);

	return 1;
}

//-------------------------------------------------------------------
// Load l'image depuis une pcx

int cPicture::LoadFromPcx(char* filename)
{
	FILE		*in_file;
	struct		stat statbuf;
	pcx_hdr		*pcx_header;
	unsigned char   *pcx;
	unsigned char	byte;
	int w,h;
	int i,numbytes,runlen,cnt,size;

	cnt=0;

	//-- check if a pcx --
	if (stricmp(strrchr(filename, '.'), ".pcx") != 0)
	{	return 0;}

	//-- Get the length of the file --
	if (stat(filename, &statbuf) != 0)
	{	return(0);}
	size= statbuf.st_size;

	//-- open file --
	in_file=fopen(filename,"rb");
	if(in_file==NULL)
	{	return 0;}

	//-- read header --
	pcx=(unsigned char*) malloc(size);
	if(!pcx)
	{	return 0;}
	fread(pcx,1,size,in_file);

	pcx_header = (pcx_hdr*) (pcx);

	//-- check of attributes --
	if(pcx_header->Bpp!=8)
	{	return 0;}

	w=pcx_header->Xmax+1;
	h=pcx_header->Ymax+1;

	//-- allocate the memory --
	numbytes= (w * h);
	if(!Allocate(w,h,8))
		return 0;
	size=numbytes;

	//-- skip header --
	pcx= pcx+ sizeof(pcx_hdr);

	// RLE decoding
	do
	{
		byte = *pcx++;

		if ((byte & 0xc0) == 0xc0)
		{
			runlen = (byte & 0x3f);
			byte = *pcx++;

			while(runlen--)
				Pixels[cnt++] = byte;
		}
		else
			Pixels[cnt++] = byte;
	}
	while (cnt < numbytes);

	//-- Load the palette --
	pcx++;

	//-- load the pal --
	for (i=0; i<MAXCOLORS; i++)
	{
		Palette[i*3+0]= pcx[i*3+0];
		Palette[i*3+1]= pcx[i*3+1];
		Palette[i*3+2]= pcx[i*3+2];
	}

	//-- close the pcx --
	fclose(in_file);

	return 1;
}

//-------------------------------------------------------------------
// save Picture to pcx

int  cPicture::SaveToPcx(char* filename)
{   FILE		*out_file;
	struct		stat statbuf;
	pcx_hdr		pcx_header;
    int         planes=1;
    int runcount;
    unsigned char runchar;
    unsigned char ch;

    //-- check existence --
    if(Width<=0 || Height<=0 || Bpp<=0)
	    return 0;

     //-- open file --
    out_file=fopen(filename,"wb");
    if(!out_file)
        return 0;

    //-- Cr�ation du header --
    memset(&pcx_header,0,sizeof(pcx_hdr));
    pcx_header.Mfg  =   10;
    pcx_header.Ver  =   5;
    pcx_header.Enc  =   1;
    pcx_header.Bpp  =   8;
    pcx_header.Xmin =   0;
    pcx_header.Ymin =   0;
    pcx_header.Xmax =   Width-1;
    pcx_header.Ymax =   Height-1;
    pcx_header.Hres =   320;
    pcx_header.Vres =   200;
    pcx_header.Reserved     =   0;
    pcx_header.ClrPlanes    =   1;
    pcx_header.Bpl  =   Width;
    pcx_header.plType   =   1;
    pcx_header.Hscreensize  = Width;
    pcx_header.Vscreensize  = Height;

    fwrite(&pcx_header,sizeof(pcx_header),1,out_file);

    //--
    for(int y=0; y<Height; y++)
    {
        runcount = 0;
        runchar = 0;
        for(int x=0; x<Width*planes; x++)
        {
            ch = Pixels[(y*Width)+x];

    	    if (runcount==0)
            {   runcount = 1;
	            runchar = ch;
	        }
	        else
            {
                if((ch != runchar) || (runcount >= 0x3f))
                {
	                if ((runcount > 1) || ((runchar & 0xC0) == 0xC0))
                        fputc((0xC0 | runcount),out_file);

    	            fputc(runchar,out_file);
	                runcount = 1;
	                runchar = ch;
	            }
	            else
	                runcount++;
    	    }
        }

        if((runcount > 1) || ((runchar & 0xC0) == 0xC0))
            fputc((0xC0 | runcount),out_file);

        fputc(runchar,out_file);
    }


    /* 256 color palette */
    fputc(12,out_file);

    for(int i=0; i<256; i++)
    {
        fputc(Palette[i*3+0],out_file);
        fputc(Palette[i*3+1],out_file);
        fputc(Palette[i*3+2],out_file);
    }

    //-- fermeture du fichier --
    fclose(out_file);

   return 1;
}

//-------------------------------------------------------------------
// Set de la palette

void cPicture::SetPalette(unsigned char* newpal)
{
    for(int i=0;i<(MAXCOLORS*3);i++)
		Palette[i]=newpal[i];
}