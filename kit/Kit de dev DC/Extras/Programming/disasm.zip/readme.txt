DCdisasm V 0.2a by Steve--

This is an early test version of my SH4 (sh7091) CPU disassembler.

Its primarely for my own use - But if anyone else who assisted me
previously can use it for anything, then be my guest.

I'll not be adding a loads of features (I want the kit instead!!! ;),
but if you find errors or mistakes, please do mail me at:

thomasn@liftoff.dk

Current filesize limit is 2mb.

Fixes since version 0.1a:
Some.

I tried making a list of everyone i wanted to send shoutouts to - Good
traditions from C64 never die ;).
The list however seemed endless, and i had probably still forgotten some.. 
So : Shoutouts to the Palladium team, and all the cool dudes in #n64dev, #dcdev &
#ps2dev. .. You know who you are.


Cheers,

Steve--
Warehouse